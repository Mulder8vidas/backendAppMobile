package com.example.login.models;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RegisterDO {

    private String username;
    private String password;
    private String nombre;
    private String apellido;
}
