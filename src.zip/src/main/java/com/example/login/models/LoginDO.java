package com.example.login.models;


import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class LoginDO {

    private String username;

    private String password;

}
