package com.example.login.models;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class TareaDO {

    private String idTrabajador;
    private String tarea;
    private String hora;
    private String direccion;
}
