package com.example.login.models;

public record Response(String respuesta,String nombre,String apellido,String foto) {
}
