package com.example.login.services;

import com.example.login.entity.TareasEntity;
import com.example.login.entity.TareasRepository;
import com.example.login.entity.TrabajadorEntity;
import com.example.login.entity.TrabajadorRepository;
import com.example.login.models.TareaDO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@Service
public class TareaService {

    @Autowired
    private TareasRepository tareasRepository;

    @Autowired
    private TrabajadorRepository trabajadorRepository;

    public boolean crearTarea(TareaDO payload){

        List<TrabajadorEntity> collect = this.trabajadorRepository.findAll().stream().filter(trabajadorEntity -> (trabajadorEntity.getNombre() + " " + trabajadorEntity.getApellido()).equalsIgnoreCase(payload.getIdTrabajador())).collect(Collectors.toList());

        if(!collect.isEmpty()){
            try {
                TareasEntity tareasEntity = new TareasEntity();
                tareasEntity.setTarea(payload.getTarea());
                tareasEntity.setDireccion(payload.getDireccion());
                tareasEntity.setHora(payload.getHora());
                tareasEntity.setIdTrabajador(collect.get(0).getId());

                TareasEntity save = this.tareasRepository.save(tareasEntity);

                return true;
            }catch (Exception ex){
                ex.printStackTrace();
                return false;
            }
        }else{
            return false;
        }




    }
}
