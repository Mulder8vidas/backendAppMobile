package com.example.login.entity;

import com.example.login.models.Accesorios;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AccesoriosRepositorio extends JpaRepository<Accesorios,Integer> {
}
