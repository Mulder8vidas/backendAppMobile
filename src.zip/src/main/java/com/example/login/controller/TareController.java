package com.example.login.controller;

import com.example.login.models.Response;
import com.example.login.models.TareaDO;
import com.example.login.services.TareaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/tarea")
public class TareController {

    @Autowired
    private TareaService tareaService;

    @PostMapping("")
    public ResponseEntity<?> crearTarea(@RequestBody TareaDO payload){

        boolean b = this.tareaService.crearTarea(payload);
        return b ? ResponseEntity.ok(new Response("Tarea creada","","","")) : ResponseEntity.badRequest().build();

    }
}
